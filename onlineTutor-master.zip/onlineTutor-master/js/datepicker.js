
$( function() {
$( "#datepicker" ).datepicker();
} );